
#include "ringlog.h"

// User-provided SPI handle and CS GPIO/pin
extern SPI_HandleTypeDef hspi1;
extern GPIO_TypeDef* FRAM_CS_GPIO;
extern uint16_t      FRAM_CS_PIN;

static inline void CS_LOW(void){ HAL_GPIO_WritePin(FRAM_CS_GPIO, FRAM_CS_PIN, GPIO_PIN_RESET); }
static inline void CS_HIGH(void){ HAL_GPIO_WritePin(FRAM_CS_GPIO, FRAM_CS_PIN, GPIO_PIN_SET); }

static HAL_StatusTypeDef spi_fram_init(void) {
    // Configure mode registers if needed by your FRAM; most require little init
    return HAL_OK;
}
static HAL_StatusTypeDef spi_fram_write(uint32_t addr, const uint8_t* buf, uint16_t len) {
    uint8_t wren = 0x06;
    uint8_t cmd_hdr[4] = {0x02, (uint8_t)(addr>>16), (uint8_t)(addr>>8), (uint8_t)addr};

    // Write Enable
    CS_LOW();
    HAL_StatusTypeDef st = HAL_SPI_Transmit(&hspi1, &wren, 1, HAL_MAX_DELAY);
    CS_HIGH(); if (st != HAL_OK) return st;

    // Write
    CS_LOW();
    st = HAL_SPI_Transmit(&hspi1, cmd_hdr, sizeof(cmd_hdr), HAL_MAX_DELAY);
    if (st == HAL_OK) st = HAL_SPI_Transmit(&hspi1, (uint8_t*)buf, len, HAL_MAX_DELAY);
    CS_HIGH();
    return st;
}
static HAL_StatusTypeDef spi_fram_read(uint32_t addr, uint8_t* buf, uint16_t len) {
    uint8_t cmd_hdr[4] = {0x03, (uint8_t)(addr>>16), (uint8_t)(addr>>8), (uint8_t)addr};
    CS_LOW();
    HAL_StatusTypeDef st = HAL_SPI_Transmit(&hspi1, cmd_hdr, sizeof(cmd_hdr), HAL_MAX_DELAY);
    if (st == HAL_OK) st = HAL_SPI_Receive(&hspi1, buf, len, HAL_MAX_DELAY);
    CS_HIGH();
    return st;
}

ringlog_storage_t RING_SPI_FRAM = {
    .init            = spi_fram_init,
    .read            = spi_fram_read,
    .write           = spi_fram_write,
    .base            = 0,
    .size            = 512 * 1024,      // Example: 512KB SPI FRAM (set to your device)
    .min_write_burst = 1                // Byte write supported
};
