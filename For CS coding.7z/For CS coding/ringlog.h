
#ifndef RINGLOG_H
#define RINGLOG_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include "stm32h7xx_hal.h"

/*** Tunable parameters ***/
#define RINGLOG_SLOT_SIZE      24U     // Fixed slot size; aligns with MRAM min 2-byte burst and our record layout
#define RINGLOG_PROBE_STEPS    16U     // Neighbor probing steps when encountering invalid/damaged slots during binary search
#define RINGLOG_SAMPLE_STRIDE  64U     // Sampling stride to estimate validity ratio during early (non-rotated) phases

/*** Fixed record layout (24 bytes) ***/
typedef struct __attribute__((packed)) {
    uint32_t seq;     // Per-epoch monotonic sequence (wrap allowed)
    uint16_t epoch;   // Epoch counter; incremented when write pointer wraps
    uint8_t  flags;   // bit0=VALID, bit1=PENDING
    uint8_t  crc8;    // CRC8 over data[16] (or header if preferred)
    uint8_t  data[16];// Application payload, fixed 16 bytes
} ringlog_record_t;   // sizeof = 24

#define RINGLOG_FLAG_VALID   (1u << 0)
#define RINGLOG_FLAG_PENDING (1u << 1)

/*** Storage backend strategy (pluggable) ***/
typedef struct {
    // Device init (bus/peripheral setup, device power-up timing, mode registers, etc.)
    HAL_StatusTypeDef (*init)(void);

    // Read/write primitives (byte-addressed)
    HAL_StatusTypeDef (*read)(uint32_t addr, uint8_t* buf, uint16_t len);
    HAL_StatusTypeDef (*write)(uint32_t addr, const uint8_t* buf, uint16_t len);

    // Capacity & characteristics
    uint32_t base;             // Base address (typically 0)
    uint32_t size;             // Total capacity in bytes
    uint8_t  min_write_burst;  // Minimum write burst size (MRAM=2; FRAM typically 1)
} ringlog_storage_t;

/*** Public API ***/
void ringlog_bind_storage(const ringlog_storage_t* ops);
void ringlog_init(void);

bool  ringlog_cold_boot_recover(void);
HAL_StatusTypeDef ringlog_append(const uint8_t data[16]);

uint32_t ringlog_current_slot(void);
uint16_t ringlog_current_epoch(void);
uint32_t ringlog_current_seq(void);
bool     ringlog_read_slot(uint32_t slot_index, ringlog_record_t* out);

/*** CRC8 (simple placeholder; replace with your preferred implementation) ***/
uint8_t ringlog_crc8(const uint8_t* buf, uint32_t len);

#endif /* RINGLOG_H */
