
#include "ringlog.h"

// User-provided I2C handle and device address
extern I2C_HandleTypeDef hi2c1;
#define FRAM_I2C_ADDR    (0x50 << 1)  // HAL uses 8-bit addresses (shift left by 1)

static HAL_StatusTypeDef i2c_fram_init(void) {
    // Most FRAMs have negligible power-up latency; delay if needed
    return HAL_OK;
}
static HAL_StatusTypeDef i2c_fram_read(uint32_t addr, uint8_t* buf, uint16_t len) {
    // Adjust to your device's address size: 16-bit shown here
    return HAL_I2C_Mem_Read(&hi2c1, FRAM_I2C_ADDR, (uint16_t)addr,
                            I2C_MEMADD_SIZE_16BIT, buf, len, HAL_MAX_DELAY);
}
static HAL_StatusTypeDef i2c_fram_write(uint32_t addr, const uint8_t* buf, uint16_t len) {
    // FRAM typically supports direct byte writes without erase; page limits vary by device
    return HAL_I2C_Mem_Write(&hi2c1, FRAM_I2C_ADDR, (uint16_t)addr,
                             I2C_MEMADD_SIZE_16BIT, (uint8_t*)buf, len, HAL_MAX_DELAY);
}

// Bind to generic framework
ringlog_storage_t RING_I2C_FRAM = {
    .init            = i2c_fram_init,
    .read            = i2c_fram_read,
    .write           = i2c_fram_write,
    .base            = 0x0000,
    .size            = 256 * 1024,       // Example: 256KB FRAM (set to your actual capacity)
    .min_write_burst = 1                 // FRAM usually supports byte writes
};
