
#include "ringlog.h"

// User-provided SPI handle and CS GPIO/pin
extern SPI_HandleTypeDef hspi1;
extern GPIO_TypeDef* MRAM_CS_GPIO;
extern uint16_t      MRAM_CS_PIN;

static inline void CS_LOW(void){ HAL_GPIO_WritePin(MRAM_CS_GPIO, MRAM_CS_PIN, GPIO_PIN_RESET); }
static inline void CS_HIGH(void){ HAL_GPIO_WritePin(MRAM_CS_GPIO, MRAM_CS_PIN, GPIO_PIN_SET); }

static HAL_StatusTypeDef mram_init(void) {
    // PM004MNIA requires power-up delay tPU ≈ 1.5 ms before reliable ops (fuse-recall + analog blocks)
    HAL_Delay(2);
    // If you need MR#2 (LT) read latency configuration, do MRWR/MRRD here (datasheet Command B1H/B5H).
    return HAL_OK;
}
static HAL_StatusTypeDef mram_write(uint32_t addr, const uint8_t* buf, uint16_t len) {
    // PM004MNIA internal array requires minimum 2-byte burst writes
    if (len & 0x1) return HAL_ERROR;

    uint8_t wren = 0x06;
    uint8_t hdr[4] = {0x02, (uint8_t)(addr>>16), (uint8_t)(addr>>8), (uint8_t)addr};

    // Write Enable
    CS_LOW();
    HAL_StatusTypeDef st = HAL_SPI_Transmit(&hspi1, &wren, 1, HAL_MAX_DELAY);
    CS_HIGH(); if (st != HAL_OK) return st;

    // Write
    CS_LOW();
    st = HAL_SPI_Transmit(&hspi1, hdr, sizeof(hdr), HAL_MAX_DELAY);
    if (st == HAL_OK) st = HAL_SPI_Transmit(&hspi1, (uint8_t*)buf, len, HAL_MAX_DELAY);
    CS_HIGH();
    return st;
}
static HAL_StatusTypeDef mram_read(uint32_t addr, uint8_t* buf, uint16_t len) {
    uint8_t hdr[4] = {0x03, (uint8_t)(addr>>16), (uint8_t)(addr>>8), (uint8_t)addr};
    CS_LOW();
    HAL_StatusTypeDef st = HAL_SPI_Transmit(&hspi1, hdr, sizeof(hdr), HAL_MAX_DELAY);
    if (st == HAL_OK) st = HAL_SPI_Receive(&hspi1, buf, len, HAL_MAX_DELAY);
    CS_HIGH();
    return st;
}

ringlog_storage_t RING_SPI_MRAM_PM004 = {
    .init            = mram_init,
    .read            = mram_read,
    .write           = mram_write,
    .base            = 0,
    .size            = 512 * 1024,     // PM004MNIA: 4 Mbit = 512 KB
    .min_write_burst = 2               // Minimum 2-byte write burst per datasheet
};
